from static.content.loader import get_all_topics, load_day_content


class GraphicsHandler:
    """کلاس مدیریت نمایش گرافیکی"""

    @staticmethod
    def create_beautiful_message(topic_name, day_number, user_progress=None):
        """ساخت پیام گرافیکی زیبا برای یک روز"""


        # پیدا کردن topic_id
        topics = get_all_topics()
        topic_id = None
        for topic in topics:
            if topic["name"] == topic_name:
                topic_id = topic["id"]
                break

        if not topic_id:
            return "❌ موضوع مورد نظر یافت نشد."

        content = load_day_content(topic_id, day_number)
        if not content:
            return "❌ محتوای مورد نظر یافت نشد."

        emoji = content["topic_emoji"]
        topic_emoji = emoji * 3

        # تعیین وضعیت تکمیل
        is_completed = False
        if user_progress and "completed_days" in user_progress:
            is_completed = day_number in user_progress["completed_days"]

        # ساخت پیام با فرمت زیبا
        message = f"""
{topic_emoji}
**{content['topic_name']}**
📅 روز {day_number} از ۲۸ • {content['week_title']}

📖 {content.get('author_quote', content['week_quote'])}

_{content['intro']}_

──────────────
{emoji} **۱۰ شکرگزاری امروز:**
"""

        # اضافه کردن موارد شکرگزاری با ایموجی موضوع
        for i, item in enumerate(content["items"], 1):
            message += f"\n{i}. {item}"

        message += "\n──────────────\n"

        if content.get('exercise'):
            message += f"💡 **تمرین امروز:** {content['exercise']}\n\n"

        if content.get('affirmation'):
            message += f"🌟 **تأکید مثبت:** _{content['affirmation']}_\n\n"

        if content.get('reflection'):
            message += f"💭 **بازتاب:** {content['reflection']}\n\n"

        if is_completed:
            message += "✅ **این روز قبلاً با موفقیت تکمیل شده است.**"
        else:
            message += f"🌟 پس از خواندن، دکمه 'امروز شکرگزار بودم' را فشار دهید."

        return message

    @staticmethod
    def create_categories_keyboard():
        """ساخت کیبورد Markup برای موضوعات"""
        topics = get_all_topics()

        keyboard = {
            "keyboard": [],
            "resize_keyboard": True,
            "one_time_keyboard": False
        }

        row = []

        for i, topic in enumerate(topics):
            row.append(topic['emoji'] + " " + topic['name'])

            # هر ردیف ۲ دکمه
            if (i + 1) % 2 == 0:
                keyboard["keyboard"].append(row)
                row = []

        # اگر دکمه باقی ماند
        if row:
            keyboard["keyboard"].append(row)

        # دکمه‌های پایین
        keyboard["keyboard"].append(["📊 پیشرفت کلی", "❓ راهنما"])
        keyboard["keyboard"].append(["👨‍💻 ارتباط با من"])

        return keyboard

    @staticmethod
    def create_day_inline_keyboard(topic_id, day_number, is_completed=False):
        """ساخت کیبورد Inline برای صفحه روز"""
        # پیدا کردن ایموجی موضوع
        topics = get_all_topics()
        topic_emoji = "🙏"
        topic_name = "موضوع"

        for topic in topics:
            if topic["id"] == topic_id:
                topic_emoji = topic["emoji"]
                topic_name = topic["name"]
                break

        keyboard = {"inline_keyboard": []}

        # ردیف اول: دکمه اصلی
        if is_completed:
            keyboard["inline_keyboard"].append([
                {
                    "text": f"✅ تکمیل شده",
                    "callback_data": f"already_{topic_id}_{day_number}"
                }
            ])
        else:
            keyboard["inline_keyboard"].append([
                {
                    "text": f"{topic_emoji} امروز شکرگزار بودم",
                    "callback_data": f"complete_{topic_id}_{day_number}"
                }
            ])

        # ردیف دوم: دکمه‌های کمکی
        keyboard["inline_keyboard"].append([
            {"text": "📊 پیشرفت این موضوع", "callback_data": f"progress_{topic_id}"},
            {"text": "💫 تشویق", "callback_data": f"encourage_{topic_id}"}
        ])

        return keyboard

    @staticmethod
    def create_main_menu_keyboard():
        """ساخت کیبورد Markup منوی اصلی"""
        return {
            "keyboard": [
                ["🎯 موضوعات شکرگزاری"],
                ["📊 پیشرفت کلی", "❓ راهنما"],
                ["👨‍💻 ارتباط با من"]

            ],
            "resize_keyboard": True,
            "one_time_keyboard": False
        }

    @staticmethod
    def create_simple_markup_keyboard(buttons):
        """ساخت کیبورد Markup ساده"""
        return {
            "keyboard": buttons,
            "resize_keyboard": True,
            "one_time_keyboard": False
        }

    @staticmethod
    def create_welcome_message(first_name=""):
        """ساخت پیام خوش‌آمد با معرفی توسعه‌دهنده"""
        developer_info = """
👨‍💻 **ساخته شده توسط فرزاد قجری**

💖 **درباره توسعه‌دهنده:**
من فرزاد قجری هستم، برنامه‌نویس و توسعه‌دهنده این ربات.
باور دارم که شکرگزاری می‌تواند زندگی هر انسانی را متحول کند.
این ربات هدیه‌ای از طرف من به همه کسانی است که می‌خواهند زندگی بهتری داشته باشند.

🌟 **یادت باشه:**
«هر روزی که شکرگزار باشی، روزی است که زندگی کرده‌ای»
        """

        emojis = "✨💫🙏💚💰😊🕊️🎯🏠🌿💖"

        return f"""
{emojis}
**✨ سلام! به ربات معجزه شکرگزاری خوش آمدید** ✨

📖 بر اساس کتاب «معجزه شکرگزاری» اثر *راندا برن*

🎯 **۸ حوزه اصلی زندگی برای شکرگزاری:**

هر موضوع ۲۸ روز تمرین اختصاصی دارد
هر روز ۱۰ شکرگزاری زیبا و مخصوص
هر هفته سطح جدیدی از شکرگزاری را تجربه می‌کنید

{developer_info}

💫 **بیایید با شکرگزاری، زندگی را متحول کنیم!**
"""

    @staticmethod
    def create_help_message():
        """ساخت پیام راهنمای زیبا"""
        return """
❓ **راهنمای استفاده از ربات**

📌 **دستورات اصلی:**
/start - شروع سفر شکرگزاری  
/help - این راهنما
/progress - پیشرفت کلی

📌 **۸ حوزه اصلی شکرگزاری:**
💚 سلامتی و تندرستی
👨‍👩‍👧‍👦 خانواده و روابط  
💰 ثروت و فراوانی
😊 شادی و آرامش
🎯 اهداف و موفقیت
🏠 زندگی مطلوب
🌿 طبیعت و کائنات
💖 عشق و معنویت

📌 **نحوه کار:**
۱. یک موضوع از ۸ موضوع انتخاب کنید
۲. هر روز ۱۰ مورد شکرگزاری مخصوص دریافت می‌کنید
۳. هر مورد را با دقت بخوانید و برای آن شکرگزاری کنید
۴. پس از اتمام، دکمه "امروز شکرگزار بودم" را فشار دهید

📌 **توصیه‌ها:**
- بهترین زمان: اول صبح
- مکان آرام
- تمرکز کامل
- هر روز ۱۰-۱۵ دقیقه وقت بگذارید
- با احساس واقعی شکرگزاری کنید

👨‍💻 **پشتیبانی:**
اگر سوالی دارید یا نیاز به کمک دارید:
از دکمه "ارتباط با من" استفاده کنید

💫 **تعهد ۲۸ روزه = تحول زندگی**
"""

    @staticmethod
    def create_contact_message():
        """ساخت پیام ارتباط با توسعه‌دهنده"""
        return """
👨‍💻 **ارتباط با توسعه‌دهنده**

<b>📛 نام کامل:</b>
<code>فرزاد قجری</code>

<b>📱 تماس مستقیم:</b>
<code>09302446141</code>

<b>📧 ایمیل:</b>
<code>farzadq.ir@gmail.com</code>

<b>🎯 خدمات تخصصی:</b>
✅ ساخت انواع ربات تلگرام و وب‌سایت
✅ طراحی اپلیکیشن موبایل و دسکتاپ
✅ برنامه‌نویسی پایتون، Django، Flask
✅ توسعه API و پایگاه داده
✅ پشتیبانی و آموزش

<b>💡 درباره من:</b>
من یک برنامه‌نویس پرشور و علاقه‌مند به ساخت ابزارهای مفید هستم.
باور دارم تکنولوژی باید زندگی مردم را بهتر کند.
این ربات یکی از پروژه‌های مورد علاقه‌ام است که با عشق ساخته شده.

<b>🌟 پیام من به شما:</b>
«شکرگزاری را شروع کنید و معجزه آن را در زندگی خود ببینید»
"""